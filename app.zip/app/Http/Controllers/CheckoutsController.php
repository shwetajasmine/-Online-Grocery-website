<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Checkout;

class CheckoutController extends Controller
{
    public function showForm()
    {
        return view('checkout.form');
    }

    public function store(Request $request)
    {
        // Validate the request data
        $validatedData = $request->validate([
            'first_name' => 'required|string',
            'last_name' => 'required|string',
            'company_name' => 'nullable|string',
            'address' => 'required|string',
            'town_city' => 'required|string',
            'country' => 'required|string',
            'postcode_zip' => 'required|string',
            'mobile' => 'required|string',
            'email' => 'required|email',
            'create_account' => 'boolean',
            'ship_different_address' => 'boolean',
            'order_notes' => 'nullable|string',
        ]);

        // Create a new checkout instance
        $checkout = new Checkout();
        $checkout->fill($validatedData);
        $checkout->save();

        // Optionally, you can return a response or redirect to a confirmation page
        return redirect()->route('confirmation');
    }

    public function showConfirmation()
    {
        // Logic to show confirmation page
        return view('checkout.confirmation'); // Adjust as per your application
    }
}
