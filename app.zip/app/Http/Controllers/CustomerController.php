<?php

namespace App\Http\Controllers;
use PDF; 
use Illuminate\Http\Request;
use App\Models\Customer;


class CustomerController extends Controller
{


    
    public function index()
    {
        $customers = Customer::all();
        return view('customer.index', compact('customers'));
    }

    public function create()    
    {
        return view('customer.create');
    }
    
    public function store(Request $request)
    {
        
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:customer,email',
            'address' => 'required|string|max:255',
            'phone_no' => 'required|string|max:20',
            'customer_image' => 'required|image', // Ensure an image file is uploaded
        ]);

        $customer = new Customer();
        $customer->name = $request->name;
        $customer->email = $request->email;
        $customer->address = $request->address;
        $customer->phone_no = $request->phone_no;

        if ($request->hasFile('customer_image')) {
            $image = $request->file('customer_image');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->storeAs('public/images', $imageName); // Store image in storage/app/public/images
            $customer->customer_image = $imageName; // Save image name to database
        }

        $customer->save();

        return redirect()->route('customer.create')->with('success', 'Customer added successfully.');
    }

    public function edit($id)
{
    $customer = Customer::findOrFail($id);
    return view('customer.edit', compact('customer'));
}

public function update(Request $request)
{
    // dd($request);

    // $request->validate([
    //     'name' => 'required|string|max:255',
    //     'email' => 'required|email|unique:customers,email',
    //     'address' => 'required|string|max:255',
    //     'phone_no' => 'required|string|max:20',
    // ]);

    $customer = Customer::findOrFail($request->id);
    if ($customer) {
        $customer->update([
            
            'name' => $request->name,
            'email' => $request->email,
            'address' => $request->address,
            'phone_no' => $request->phone_no,
            
        ]);

        return response()->json(['message' => 'Employee updated successfully'], 200);
    } else {
        return response()->json(['error' => 'Employee not found'], 404);
    }
}


public function uploadImage(Request $request)
    {
        try {
            // Validate the request
            // $request->validate([
            //     'customer_image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048', // Adjust validation rules as needed
            // ]);
            // Check if the request has an image file
            if ($request->hasFile('image')) {
                // Get the uploaded image file
                $image = $request->file('image');
                // Define the storage path for the image
                $storagePath = 'public/images'; // Change this to your desired storage path
    
                // Generate a unique image name to prevent overwriting
                $imageName = time() . '.' . $image->getClientOriginalExtension();
    
                // Move the uploaded image to the storage path
                $image->storeAs($storagePath, $imageName);

                $customer = Customer::where('id', $request->id)->first();

                $customer->update([
            
                    'customer_image' => $imageName
                    
                ]);
                
                // Return the image URL or any other response as needed
                return response()->json(['success' => true, 'image_url' => asset('storage/images/' . $imageName)]);
            }
    
            // Return error response if no image is found
            return response()->json(['success' => false, 'message' => 'No image found'], 400); // Use appropriate HTTP status code
            
        } catch (\Exception $e) {
            // Log the error
            \Log::error('Error uploading image: ' . $e->getMessage());
            
            // Return a response with a 500 status code and error message
            return response()->json(['success' => false, 'message' => 'An error occurred while uploading the image.'], 500);
        }
    }
    
    public function destroy($id)
    {
        $customer = Customer::findOrFail($id);
        $customer->delete();
        return redirect()->route('customer.index')->with('success', 'Customer deleted successfully.');
    }

    public function print(Customer $customer)
    {
        // Fetch the customer details and pass them to the view
        return view('customer.print', compact('customer'));
    }

    public function generatePDF($customerId)
    {
        $customer = Customer::findOrFail($customerId);

        $pdf = PDF::loadView('customer.print', compact('customer'));

        return $pdf->download('invoice.pdf');
    }
}