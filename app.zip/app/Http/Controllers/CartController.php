<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class CartController extends Controller
{
    public function index()
    {
        $cart = session()->get('cart', []);
        $totalQuantity = $this->getTotalQuantity($cart);
        $totalPrice = $this->getTotalPrice($cart);

        return view('user.cart.index', compact('cart', 'totalQuantity', 'totalPrice'));
    }

    public function addToCart(Request $request)
    {
        $cart = session()->get('cart', []);
        $product_id = $request->input('product_id');
        $quantity = $request->input('quantity', 1);

        if (isset($cart[$product_id])) {
            $cart[$product_id]['quantity'] += $quantity;
        } else {
            $product = Product::find($product_id);
            $cart[$product_id] = [
                "name" => $product->name,
                "quantity" => $quantity,
                "price" => $product->price,
                "image" => $product->image
            ];
        }

        session()->put('cart', $cart);
        return response()->json(['success' => 'Product added to cart successfully']);
    }

    private function getTotalQuantity($cart)
    {
        return array_sum(array_column($cart, 'quantity'));
    }

    private function getTotalPrice($cart)
    {
        $totalPrice = 0;
        foreach ($cart as $item) {
            $totalPrice += $item['price'] * $item['quantity'];
        }
        return $totalPrice;
    }

    public function updateCart(Request $request)
    {
        $cart = session()->get('cart', []);
        $productId = $request->input('product_id');
        $quantity = $request->input('quantity');

        if (isset($cart[$productId])) {
            $cart[$productId]['quantity'] = $quantity;
            session()->put('cart', $cart);
            return response()->json(['success' => 'Cart updated successfully.']);
        }

        return response()->json(['error' => 'Product not found in cart.'], 404);
    }

    public function remove(Request $request, $id)
    {
        $cart = session()->get('cart', []);

        if (isset($cart[$id])) {
            unset($cart[$id]);
            session()->put('cart', $cart);
        }

        return redirect()->route('cart.index')->with('success', 'Product removed successfully');
    }
}
