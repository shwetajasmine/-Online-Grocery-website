<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CustomerDetail;

class CheckoutController extends Controller
{
    public function showForm()
    {
        return view('user.checkout.form');
    }

    public function submitForm(Request $request)
    {
        // Validate the request
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255',
            'phone' => 'required|string|max:20',
            'address' => 'required|string|max:500',
        ]);
    
        // Create a new customer record in the database
        $customer = CustomerDetail::create($validatedData);
    
        // Store customer data in the session
        $request->session()->put('customer', $customer);
    
        // Redirect to the confirmation page with customer data
        return redirect()->route('checkout.confirmation');
    }
    
    public function showConfirmationPage(Request $request)
    {
        // Retrieve customer data from session
        $customer = $request->session()->get('customer');

        // Check if customer data exists
        if (!$customer) {
            return redirect()->route('checkout.form')->with('error', 'No customer data found.');
        }

        // Retrieve cart data
        $cart = $this->getCartData();

        // Calculate the total price
        $totalPrice = $this->calculateTotalPrice($cart);

        // Display the confirmation page with customer and cart details
        return view('user.checkout.confirmation', compact('customer', 'cart', 'totalPrice'));
    }

    // Method to retrieve cart data
    private function getCartData()
    {
        // Fetch cart data from a session variable
        return session('cart', []); // Adjust according to your actual cart data retrieval logic
    }

    // Method to calculate the total price
    private function calculateTotalPrice($cart)
    {
        // Calculate the total price of the items in the cart
        return array_sum(array_map(function($item) {
            return $item['price'] * $item['quantity'];
        }, $cart));
    }
}
