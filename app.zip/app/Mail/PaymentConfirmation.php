<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class PaymentConfirmation extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public $customer;
    public $product;

    /**
     * Create a new message instance.
     *
     * @param $customer
     * @param $product
     */
    public function __construct($customer, $product)
    {
        $this->customer = $customer;
        $this->product = $product;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('emails.payment_confirmation')
                    ->subject('Payment Confirmation');
    }
}
